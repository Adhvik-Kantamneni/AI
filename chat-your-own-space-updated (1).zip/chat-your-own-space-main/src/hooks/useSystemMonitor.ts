import { useState, useEffect, useCallback } from "react";

interface SystemStats {
  memoryUsage: number; // Percentage (0-100)
  memoryLimit: number; // In MB
  memoryUsed: number; // In MB
  isHighLoad: boolean;
  isCritical: boolean;
  deviceMemory?: number; // Device RAM in GB
  warnings: string[];
}

export const useSystemMonitor = (isModelActive: boolean) => {
  const [stats, setStats] = useState<SystemStats>({
    memoryUsage: 0,
    memoryLimit: 0,
    memoryUsed: 0,
    isHighLoad: false,
    isCritical: false,
    warnings: [],
  });

  const updateStats = useCallback(() => {
    if (!isModelActive) return;

    const warnings: string[] = [];
    let memoryUsage = 0;
    let memoryLimit = 0;
    let memoryUsed = 0;

    // Check if Performance Memory API is available
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      memoryLimit = memory.jsHeapSizeLimit / (1024 * 1024); // Convert to MB
      memoryUsed = memory.usedJSHeapSize / (1024 * 1024); // Convert to MB
      memoryUsage = (memoryUsed / memoryLimit) * 100;
    } else {
      // Fallback: estimate based on device memory
      const deviceMem = (navigator as any).deviceMemory || 4; // Default to 4GB if unavailable
      memoryLimit = deviceMem * 1024 * 0.6; // Assume browser can use 60% of device memory
      memoryUsed = memoryLimit * 0.3; // Rough estimate
      memoryUsage = 30;
    }

    // Determine load status
    const isHighLoad = memoryUsage > 70;
    const isCritical = memoryUsage > 85;

    // Generate warnings
    if (isCritical) {
      warnings.push("Critical memory usage! Browser may become unstable.");
      warnings.push("Consider closing other tabs or reloading the page.");
    } else if (isHighLoad) {
      warnings.push("High memory usage detected.");
      warnings.push("Performance may be affected.");
    }

    // Device memory check
    const deviceMemory = (navigator as any).deviceMemory;
    if (deviceMemory && deviceMemory < 4) {
      warnings.push("Low device memory detected. Consider using a smaller model.");
    }

    setStats({
      memoryUsage: Math.min(memoryUsage, 100),
      memoryLimit: Math.round(memoryLimit),
      memoryUsed: Math.round(memoryUsed),
      isHighLoad,
      isCritical,
      deviceMemory,
      warnings,
    });
  }, [isModelActive]);

  useEffect(() => {
    if (!isModelActive) return;

    // Update immediately
    updateStats();

    // Update every 2 seconds
    const interval = setInterval(updateStats, 2000);

    return () => clearInterval(interval);
  }, [isModelActive, updateStats]);

  return stats;
};
