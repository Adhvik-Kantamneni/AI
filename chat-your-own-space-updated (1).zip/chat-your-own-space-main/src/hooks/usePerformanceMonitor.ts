import { useState, useEffect, useCallback } from "react";

export interface PerformanceMetrics {
  responseTime: number | null;
  tokensPerSecond: number | null;
  inferenceTime: number | null;
  fps: number;
  cpuUsage: number | null;
  gpuUtilization: number | null;
  averageResponseTime: number;
  totalRequests: number;
}

export const usePerformanceMonitor = () => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    responseTime: null,
    tokensPerSecond: null,
    inferenceTime: null,
    fps: 0,
    cpuUsage: null,
    gpuUtilization: null,
    averageResponseTime: 0,
    totalRequests: 0,
  });

  const [responseTimes, setResponseTimes] = useState<number[]>([]);

  // FPS tracking
  useEffect(() => {
    let frameCount = 0;
    let lastTime = performance.now();
    let animationFrameId: number;

    const measureFPS = () => {
      frameCount++;
      const currentTime = performance.now();
      
      if (currentTime >= lastTime + 1000) {
        const fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
        setMetrics(prev => ({ ...prev, fps }));
        frameCount = 0;
        lastTime = currentTime;
      }
      
      animationFrameId = requestAnimationFrame(measureFPS);
    };

    animationFrameId = requestAnimationFrame(measureFPS);
    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  // CPU and GPU monitoring (if available)
  useEffect(() => {
    const interval = setInterval(async () => {
      // Check for Performance API extensions
      if ('performance' in window && 'memory' in performance) {
        const memory = (performance as any).memory;
        // Estimate CPU usage based on memory pressure
        const usagePercent = (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100;
        setMetrics(prev => ({ ...prev, cpuUsage: Math.round(usagePercent) }));
      }

      // GPU utilization (WebGPU adapter info if available)
      if ('gpu' in navigator) {
        try {
          const adapter = await (navigator as any).gpu.requestAdapter();
          if (adapter && adapter.limits) {
            // This is a rough estimation based on available WebGPU info
            setMetrics(prev => ({ ...prev, gpuUtilization: 0 })); // Placeholder
          }
        } catch (e) {
          // GPU info not available
        }
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const startTracking = useCallback(() => {
    return performance.now();
  }, []);

  const endTracking = useCallback((startTime: number, tokensGenerated: number) => {
    const endTime = performance.now();
    const responseTime = endTime - startTime;
    const inferenceTime = responseTime; // In this case, same as response time
    const tokensPerSecond = tokensGenerated / (responseTime / 1000);

    setResponseTimes(prev => [...prev, responseTime].slice(-10)); // Keep last 10
    const newTotalRequests = metrics.totalRequests + 1;
    const averageResponseTime = 
      (metrics.averageResponseTime * metrics.totalRequests + responseTime) / newTotalRequests;

    setMetrics(prev => ({
      ...prev,
      responseTime: Math.round(responseTime),
      tokensPerSecond: Math.round(tokensPerSecond * 10) / 10,
      inferenceTime: Math.round(inferenceTime),
      averageResponseTime: Math.round(averageResponseTime),
      totalRequests: newTotalRequests,
    }));
  }, [metrics.totalRequests, metrics.averageResponseTime]);

  return {
    metrics,
    startTracking,
    endTracking,
    responseTimes,
  };
};
