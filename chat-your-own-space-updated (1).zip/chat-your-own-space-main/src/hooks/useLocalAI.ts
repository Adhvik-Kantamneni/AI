import { useState, useCallback, useRef } from "react";
import { pipeline, env, TextStreamer } from "@huggingface/transformers";

// Configure transformers.js to use WebGPU when available
env.allowLocalModels = false;
env.backends.onnx.wasm.numThreads = 1;

export interface Message {
  role: "user" | "assistant";
  content: string;
}

export const useLocalAI = (onPerformanceTrack?: {
  startTracking: () => number;
  endTracking: (startTime: number, tokensGenerated: number) => void;
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [modelReady, setModelReady] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState({ file: "", progress: 0 });
  const [streamingContent, setStreamingContent] = useState("");
  const generatorRef = useRef<any>(null);

  const initializeModel = useCallback(async () => {
    if (generatorRef.current) return;

    setIsInitializing(true);
    try {
      // Using a smaller model for faster loading and responses
      const generator = await pipeline(
        "text-generation",
        "onnx-community/Qwen2.5-0.5B-Instruct",
        {
          device: "webgpu",
          dtype: "q4", // Quantized for speed
          progress_callback: (progress: any) => {
            if (progress.status === 'progress') {
              setLoadingProgress({
                file: progress.file || progress.name || 'model files',
                progress: Math.round(progress.progress || 0)
              });
            }
          }
        }
      );
      generatorRef.current = generator;
      setModelReady(true);
      
      // Add welcome message
      setMessages([
        {
          role: "assistant",
          content: "Hello! I'm running locally in your browser using WebGPU. Fast loading and responses! How can I help you?",
        },
      ]);
    } catch (error) {
      console.error("Error initializing model:", error);
      setMessages([
        {
          role: "assistant",
          content: "Sorry, I couldn't initialize the AI model. Please make sure your browser supports WebGPU and try refreshing the page.",
        },
      ]);
    } finally {
      setIsInitializing(false);
    }
  }, []);

  const sendMessage = useCallback(
    async (userMessage: string) => {
      if (!generatorRef.current || isLoading) return;

      const newUserMessage: Message = {
        role: "user",
        content: userMessage,
      };

      setMessages((prev) => [...prev, newUserMessage]);
      setIsLoading(true);
      setStreamingContent("");

      const startTime = onPerformanceTrack?.startTracking();

      try {
        // Create conversation history - limit to last 4 messages for faster processing
        const recentMessages = [...messages, newUserMessage].slice(-4);
        const conversationHistory = recentMessages
          .map((msg) => `${msg.role === "user" ? "User" : "Assistant"}: ${msg.content}`)
          .join("\n");

        const prompt = `${conversationHistory}\nAssistant:`;

        let fullResponse = "";
        let isCapturing = false;

        // Create a custom streamer that updates state as tokens come in
        const streamer = new TextStreamer(generatorRef.current.tokenizer, {
          skip_prompt: true,
          skip_special_tokens: true,
          callback_function: (text: string) => {
            // Start capturing after we see the response pattern
            if (!isCapturing) {
              if (text.includes("Assistant:")) {
                isCapturing = true;
                const parts = text.split("Assistant:");
                if (parts.length > 1) {
                  fullResponse = parts[parts.length - 1];
                  setStreamingContent(fullResponse);
                }
              } else {
                // If no "Assistant:" marker, just stream everything
                fullResponse += text;
                setStreamingContent(fullResponse);
              }
            } else {
              fullResponse += text;
              setStreamingContent(fullResponse);
            }
          },
        });

        await generatorRef.current(prompt, {
          max_new_tokens: 200,
          temperature: 0.7,
          do_sample: true,
          top_k: 50,
          top_p: 0.9,
          repetition_penalty: 1.15,
          streamer,
        });

        // Finalize the message
        const finalResponse = fullResponse.trim() || "I apologize, but I couldn't generate a response.";
        
        setMessages((prev) => [...prev, {
          role: "assistant",
          content: finalResponse,
        }]);
        setStreamingContent("");

        // Track performance metrics
        if (startTime !== undefined && onPerformanceTrack) {
          const tokensGenerated = finalResponse.split(/\s+/).length;
          onPerformanceTrack.endTracking(startTime, tokensGenerated);
        }
      } catch (error) {
        console.error("Error generating response:", error);
        setStreamingContent("");
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "Sorry, I encountered an error while generating a response. Please try again.",
          },
        ]);
      } finally {
        setIsLoading(false);
      }
    },
    [messages, isLoading, onPerformanceTrack]
  );

  return {
    messages,
    isLoading,
    isInitializing,
    modelReady,
    loadingProgress,
    streamingContent,
    sendMessage,
    initializeModel,
  };
};
