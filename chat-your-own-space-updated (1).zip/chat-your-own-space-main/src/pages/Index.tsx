import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import ChatMessage from "@/components/ChatMessage";
import ChatInput from "@/components/ChatInput";
import SystemMonitor from "@/components/SystemMonitor";
import { useLocalAI } from "@/hooks/useLocalAI";
import { useSystemMonitor } from "@/hooks/useSystemMonitor";
import { usePerformanceMonitor } from "@/hooks/usePerformanceMonitor";
import { PerformanceDialog } from "@/components/PerformanceDialog";
import { Brain, Loader2, Activity } from "lucide-react";

const Index = () => {
  const [isPerformanceOpen, setIsPerformanceOpen] = useState(false);
  const { metrics, startTracking, endTracking, responseTimes } = usePerformanceMonitor();
  
  const {
    messages,
    isLoading,
    isInitializing,
    modelReady,
    loadingProgress,
    streamingContent,
    sendMessage,
    initializeModel,
  } = useLocalAI({ startTracking, endTracking });

  const systemStats = useSystemMonitor(modelReady);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="flex flex-col h-screen bg-gradient-mesh bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-primary rounded-xl shadow-md">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                Local AI Chat
              </h1>
              <p className="text-xs text-muted-foreground">
                Powered by WebGPU • Runs in your browser
              </p>
            </div>
          </div>
          {modelReady && (
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsPerformanceOpen(true)}
                className="gap-2"
              >
                <Activity className="h-4 w-4" />
                Performance
              </Button>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/20 border border-accent/30">
                <div className="h-2 w-2 rounded-full bg-accent animate-pulse-glow" />
                <span className="text-xs font-medium text-accent-foreground">Model Ready</span>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {!modelReady ? (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center max-w-md animate-fade-in">
              <div className="mb-6 inline-flex p-6 bg-gradient-primary rounded-3xl shadow-lg">
                <Brain className="h-16 w-16 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-4 bg-gradient-primary bg-clip-text text-transparent">
                Run AI Locally
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Experience AI chat that runs entirely in your browser using WebGPU acceleration.
                No API keys, no servers, complete privacy.
              </p>
              <Button
                onClick={initializeModel}
                disabled={isInitializing}
                size="lg"
                className="bg-gradient-primary hover:opacity-90 shadow-md text-base px-8 transition-all"
              >
                {isInitializing ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Loading Model...
                  </>
                ) : (
                  "Initialize AI Model"
                )}
              </Button>
              {isInitializing && (
                <div className="mt-6 w-full max-w-md space-y-3 animate-fade-in">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground font-medium">
                        {loadingProgress.file}
                      </span>
                      <span className="text-primary font-bold">
                        {loadingProgress.progress}%
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-primary transition-all duration-300 ease-out"
                        style={{ width: `${loadingProgress.progress}%` }}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">
                    Downloading and initializing model... This may take a minute on first load.
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <>
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto lg:border-r lg:border-border">
              <div className="container mx-auto max-w-4xl px-4 py-6">
                <div className="space-y-4">
                  {messages.map((message, index) => (
                    <ChatMessage
                      key={index}
                      role={message.role}
                      content={message.content}
                    />
                  ))}
                  {isLoading && (
                    <div className="flex justify-start animate-fade-in">
                      <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-card border border-border shadow-sm">
                        {streamingContent ? (
                          <p className="whitespace-pre-wrap break-words text-sm leading-relaxed">
                            {streamingContent}
                            <span className="inline-block w-2 h-4 ml-1 bg-primary animate-pulse" />
                          </p>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Loader2 className="h-4 w-4 animate-spin text-primary" />
                            <span className="text-sm text-muted-foreground">Thinking...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>
            </div>

            {/* Input Area */}
            <div className="container mx-auto max-w-4xl lg:max-w-full">
              <ChatInput onSendMessage={sendMessage} disabled={isLoading} />
            </div>

            {/* System Monitor Sidebar */}
            <aside className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-border bg-card/30 backdrop-blur-sm p-4 overflow-y-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
                    <Brain className="h-4 w-4 text-white" />
                  </div>
                  <h3 className="font-semibold text-sm">System Monitor</h3>
                </div>
                <SystemMonitor
                  memoryUsage={systemStats.memoryUsage}
                  memoryLimit={systemStats.memoryLimit}
                  memoryUsed={systemStats.memoryUsed}
                  isHighLoad={systemStats.isHighLoad}
                  isCritical={systemStats.isCritical}
                  deviceMemory={systemStats.deviceMemory}
                  warnings={systemStats.warnings}
                />
              </div>
            </aside>
          </>
        )}
      </main>

      {/* Performance Dialog */}
      <PerformanceDialog
        open={isPerformanceOpen}
        onOpenChange={setIsPerformanceOpen}
        metrics={metrics}
        responseTimes={responseTimes}
      />
    </div>
  );
};

export default Index;
