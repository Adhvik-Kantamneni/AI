import { cn } from "@/lib/utils";
import { AlertTriangle, Cpu, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface SystemMonitorProps {
  memoryUsage: number;
  memoryLimit: number;
  memoryUsed: number;
  isHighLoad: boolean;
  isCritical: boolean;
  deviceMemory?: number;
  warnings: string[];
}

const SystemMonitor = ({
  memoryUsage,
  memoryLimit,
  memoryUsed,
  isHighLoad,
  isCritical,
  deviceMemory,
  warnings,
}: SystemMonitorProps) => {
  const getStatusColor = () => {
    if (isCritical) return "text-destructive";
    if (isHighLoad) return "text-yellow-600 dark:text-yellow-500";
    return "text-accent";
  };

  const getProgressColor = () => {
    if (isCritical) return "bg-destructive";
    if (isHighLoad) return "bg-yellow-500";
    return "";
  };

  return (
    <div className="space-y-3">
      {/* Memory Usage Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Cpu className={cn("h-4 w-4", getStatusColor())} />
            <span className="font-medium">System Load</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">
                    Shows browser memory usage. The AI model runs in your browser and uses system
                    resources. High usage may slow down performance.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <span className={cn("font-semibold tabular-nums", getStatusColor())}>
            {memoryUsage.toFixed(1)}%
          </span>
        </div>
        <Progress
          value={memoryUsage}
          className="h-2"
          indicatorClassName={getProgressColor()}
        />
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            {memoryUsed} MB / {memoryLimit} MB
          </span>
          {deviceMemory && <span>{deviceMemory} GB Device RAM</span>}
        </div>
      </div>

      {/* Warnings */}
      {warnings.length > 0 && (
        <Alert
          variant={isCritical ? "destructive" : "default"}
          className={cn(
            "animate-fade-in",
            !isCritical && "border-yellow-500 bg-yellow-50 dark:bg-yellow-950/20"
          )}
        >
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-xs space-y-1">
            {warnings.map((warning, index) => (
              <div key={index}>{warning}</div>
            ))}
          </AlertDescription>
        </Alert>
      )}

      {/* Status Indicators */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <div
            className={cn(
              "h-2 w-2 rounded-full",
              isCritical
                ? "bg-destructive animate-pulse"
                : isHighLoad
                ? "bg-yellow-500 animate-pulse"
                : "bg-accent"
            )}
          />
          <span>
            {isCritical ? "Critical" : isHighLoad ? "High Load" : "Normal"}
          </span>
        </div>
      </div>
    </div>
  );
};

export default SystemMonitor;
