import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PerformanceMetrics } from "@/hooks/usePerformanceMonitor";
import { Activity, Zap, Clock, Cpu, MonitorSmartphone } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface PerformanceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  metrics: PerformanceMetrics;
  responseTimes: number[];
}

export const PerformanceDialog = ({
  open,
  onOpenChange,
  metrics,
  responseTimes,
}: PerformanceDialogProps) => {
  const getPerformanceColor = (value: number, thresholds: { good: number; warning: number }) => {
    if (value <= thresholds.good) return "text-green-500";
    if (value <= thresholds.warning) return "text-yellow-500";
    return "text-red-500";
  };

  const formatTime = (ms: number | null) => {
    if (ms === null) return "N/A";
    return ms < 1000 ? `${ms}ms` : `${(ms / 1000).toFixed(2)}s`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            Performance Metrics
          </DialogTitle>
          <DialogDescription>
            Real-time performance statistics for AI model and browser
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Response Time Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              <h3 className="font-semibold text-sm">Response Time</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-muted/50 rounded-lg p-3 space-y-1">
                <p className="text-xs text-muted-foreground">Last Response</p>
                <p className={`text-2xl font-bold ${
                  metrics.responseTime 
                    ? getPerformanceColor(metrics.responseTime, { good: 2000, warning: 5000 })
                    : ""
                }`}>
                  {formatTime(metrics.responseTime)}
                </p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3 space-y-1">
                <p className="text-xs text-muted-foreground">Average Response</p>
                <p className="text-2xl font-bold text-primary">
                  {formatTime(metrics.averageResponseTime || null)}
                </p>
              </div>
            </div>
          </div>

          {/* Model Inference Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" />
              <h3 className="font-semibold text-sm">Model Inference</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-muted/50 rounded-lg p-3 space-y-1">
                <p className="text-xs text-muted-foreground">Tokens/Second</p>
                <p className="text-2xl font-bold text-primary">
                  {metrics.tokensPerSecond ? metrics.tokensPerSecond.toFixed(1) : "N/A"}
                </p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3 space-y-1">
                <p className="text-xs text-muted-foreground">Inference Time</p>
                <p className="text-2xl font-bold text-primary">
                  {formatTime(metrics.inferenceTime)}
                </p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3 space-y-1 col-span-2">
                <p className="text-xs text-muted-foreground">Total Requests</p>
                <p className="text-2xl font-bold text-primary">
                  {metrics.totalRequests}
                </p>
              </div>
            </div>
          </div>

          {/* Browser Performance Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Cpu className="h-4 w-4 text-primary" />
              <h3 className="font-semibold text-sm">Browser Performance</h3>
            </div>
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">FPS</p>
                  <p className={`text-lg font-bold ${
                    getPerformanceColor(60 - metrics.fps, { good: 0, warning: 15 })
                  }`}>
                    {metrics.fps}
                  </p>
                </div>
                <Progress value={(metrics.fps / 60) * 100} className="h-2" />
              </div>

              {metrics.cpuUsage !== null && (
                <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">Memory Usage</p>
                    <p className={`text-lg font-bold ${
                      getPerformanceColor(metrics.cpuUsage, { good: 50, warning: 75 })
                    }`}>
                      {metrics.cpuUsage}%
                    </p>
                  </div>
                  <Progress value={metrics.cpuUsage} className="h-2" />
                </div>
              )}

              {metrics.gpuUtilization !== null && (
                <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">GPU Utilization</p>
                    <p className="text-lg font-bold text-primary">
                      {metrics.gpuUtilization}%
                    </p>
                  </div>
                  <Progress value={metrics.gpuUtilization} className="h-2" />
                </div>
              )}
            </div>
          </div>

          {/* Response Time History */}
          {responseTimes.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <MonitorSmartphone className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-sm">Recent Response Times</h3>
              </div>
              <div className="flex items-end gap-1 h-20 bg-muted/30 rounded-lg p-2">
                {responseTimes.map((time, index) => {
                  const maxTime = Math.max(...responseTimes);
                  const height = (time / maxTime) * 100;
                  return (
                    <div
                      key={index}
                      className="flex-1 bg-gradient-primary rounded-sm transition-all hover:opacity-80"
                      style={{ height: `${height}%` }}
                      title={`${time.toFixed(0)}ms`}
                    />
                  );
                })}
              </div>
              <p className="text-xs text-muted-foreground text-center">
                Last {responseTimes.length} responses
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
